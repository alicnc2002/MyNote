<?php
/**
 * POST /login
 * body: {"username": "...", "password": "..."}
 * 200 -> {"token": "..."}
 * 401 -> {"error": "..."}
 */

require_once __DIR__ . '/lib/token.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    pn_json_error(405, 'Use POST');
}

$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) {
    pn_json_error(400, 'Expected a JSON body');
}

$username = trim((string)($body['username'] ?? ''));
$password = (string)($body['password'] ?? '');

if ($username === '' || $password === '') {
    pn_json_error(400, 'username and password are both required');
}

$users = PN_USERS;
if (!array_key_exists($username, $users)) {
    // Deliberately vague -- don't reveal whether the username exists.
    pn_json_error(401, 'Invalid username or password');
}

if (!password_verify($password, $users[$username])) {
    pn_json_error(401, 'Invalid username or password');
}

echo json_encode(['token' => pn_generate_token($username)]);
