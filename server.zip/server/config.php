<?php
/**
 * MyNote server config.
 *
 * Don't edit the values in this file directly -- copy config.local.example.php
 * to config.local.php and put your real secret key / storage path / users
 * there instead. config.local.php is loaded first if it exists; anything it
 * doesn't define falls back to the (insecure, placeholder) defaults below,
 * which exist only so the app fails loudly rather than silently.
 */

if (is_file(__DIR__ . '/config.local.php')) {
    require __DIR__ . '/config.local.php';
}

// A long, random, secret string used to sign session tokens (HMAC-SHA256).
// Generate one with: php -r "echo bin2hex(random_bytes(32));"
// If this ever leaks, change it -- every existing token becomes invalid.
if (!defined('PN_SECRET_KEY')) {
    define('PN_SECRET_KEY', 'CHANGE-ME-TO-A-RANDOM-64-CHAR-HEX-STRING');
}

// Where saved/temp files actually live on disk. MUST be outside your
// public_html / webroot, so files can never be fetched directly by URL --
// only through the PHP endpoints below, which check the login token first.
//
// Typical cPanel layout: public_html/api/ (this code) sits inside the
// webroot, but its storage sits one level above webroot, e.g.:
//   /home/youruser/mynote_storage/
// Adjust this path to match your actual hosting account's home directory.
if (!defined('PN_STORAGE_DIR')) {
    define('PN_STORAGE_DIR', dirname(__DIR__, 2) . '/mynote_storage');
}

// How long a login token stays valid, in seconds. 30 days by default --
// the client only logs in once and keeps reusing the token until you log
// out, so this mainly controls how long a *stolen* token would work.
if (!defined('PN_TOKEN_TTL')) {
    define('PN_TOKEN_TTL', 30 * 24 * 60 * 60);
}

// Users allowed to log in: username => password hash. Generate a hash with
// hash_password.php (see that file's instructions), or from a PHP CLI:
//   php -r "echo password_hash('yourpassword', PASSWORD_DEFAULT);"
// Never store a plain-text password here.
if (!defined('PN_USERS')) {
    define('PN_USERS', []);
}

// Optional: close the race condition where anyone who finds setup.php's URL
// before you do can create the first (only) account for themselves.
// Uncomment the line below and replace the placeholder with a random
// string of your own choosing, BEFORE uploading server/ to your host.
// Generate one with: php -r "echo bin2hex(random_bytes(16));"
//
// With this set, setup.php refuses to do anything -- won't even show its
// form -- unless the same value is supplied: as ?key=... in the URL (the
// browser flow) or as "setup_key" in the JSON body (the app's own Create
// Account button, which has a matching field for it). Leave this commented
// out if you'd rather just run setup.php immediately after uploading and
// accept that (documented, narrow) window instead.
//
// IMPORTANT: this must live here in config.php, not in config.local.php --
// config.local.php doesn't exist yet at this point (setup.php creates it),
// and setup.php treats config.local.php's mere existence as "already set
// up", so creating it early would lock you out of your own setup.
//
// if (!defined('PN_SETUP_KEY')) {
//     define('PN_SETUP_KEY', 'CHANGE-ME-TO-A-RANDOM-STRING-BEFORE-UPLOADING');
// }
