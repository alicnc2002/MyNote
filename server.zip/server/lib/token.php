<?php
/**
 * Stateless login tokens: username + expiry, signed with HMAC-SHA256 using
 * PN_SECRET_KEY. No server-side session storage needed -- validating a
 * token is just re-computing the signature and comparing, and revocation
 * is "the shared secret changed" rather than a database row to delete.
 * That trade-off is deliberate: it keeps this deployable on plain shared
 * hosting with no database at all.
 */

require_once __DIR__ . '/../config.php';

// NOTE: usernames must not contain "." -- the token format is
// "username.expiry.signature", and a dot in the username would make
// validation fail closed (rejected, not misparsed) rather than succeed
// incorrectly, but it's simplest to just not use dots in PN_USERS keys.
function pn_generate_token(string $username): string
{
    $expires = time() + PN_TOKEN_TTL;
    $payload = $username . '.' . $expires;
    $signature = hash_hmac('sha256', $payload, PN_SECRET_KEY);
    return base64_encode($payload . '.' . $signature);
}

/**
 * Returns the username if the token is valid and unexpired, or null.
 */
function pn_validate_token(?string $token): ?string
{
    if (!$token) {
        return null;
    }

    $decoded = base64_decode($token, true);
    if ($decoded === false) {
        return null;
    }

    $parts = explode('.', $decoded);
    if (count($parts) !== 3) {
        return null;
    }
    [$username, $expires, $signature] = $parts;

    $expectedPayload = $username . '.' . $expires;
    $expectedSignature = hash_hmac('sha256', $expectedPayload, PN_SECRET_KEY);

    // Constant-time compare -- avoids leaking signature bytes via timing.
    if (!hash_equals($expectedSignature, $signature)) {
        return null;
    }

    if ((int)$expires < time()) {
        return null;
    }

    $users = PN_USERS;
    if (!array_key_exists($username, $users)) {
        return null; // user removed from config since the token was issued
    }

    return $username;
}

/**
 * Reads "Authorization: Bearer <token>" from the request, validates it,
 * and either returns the username or sends a 401 JSON error and exits.
 */
function pn_require_auth(): string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (stripos($header, 'Bearer ') !== 0) {
        pn_json_error(401, 'Missing or malformed Authorization header');
    }
    $token = substr($header, 7);

    $username = pn_validate_token($token);
    if ($username === null) {
        pn_json_error(401, 'Invalid or expired session, please log in again');
    }

    return $username;
}

function pn_json_error(int $httpStatus, string $message): void
{
    http_response_code($httpStatus);
    header('Content-Type: application/json');
    echo json_encode(['error' => $message]);
    exit;
}
