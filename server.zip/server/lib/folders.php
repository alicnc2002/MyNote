<?php
/**
 * Shared folder-name validation for server/files/*.php.
 *
 * A "folder" here is always a single path segment directly under the
 * logged-in user's storage directory -- never nested, never containing
 * "..", "/" or "\", so there's no path-traversal surface no matter what a
 * client sends. "saved" and "temp" are the two built-in folders the rest
 * of the app already relies on (temp = background autosave snapshots,
 * saved = the default folder file dialogs use); anything else is a
 * user-created folder (see files/create_folder.php) and has to pass the
 * same character whitelist as those two do implicitly.
 */

function pn_sanitize_folder(?string $folder): ?string
{
    $folder = trim((string)$folder);
    if ($folder === '') {
        return 'saved';
    }
    if (strpos($folder, '/') !== false || strpos($folder, '\\') !== false || strpos($folder, '..') !== false) {
        return null;
    }
    if (!preg_match('/^[A-Za-z0-9 _-]{1,100}$/', $folder)) {
        return null;
    }
    return $folder;
}
