<?php
/**
 * POST /files/create_folder.php
 * header: Authorization: Bearer <token>
 * body: {"folder": "..."}
 * 200 -> {"success": true, "folder": "..."}
 *
 * "saved" and "temp" already exist implicitly (see files/list_folders.php),
 * so this is really only needed for extra, user-named folders to organize
 * saved files into. Creating a folder that already exists is not an error
 * -- it just succeeds, same as mkdir -p.
 */

require_once __DIR__ . '/../lib/token.php';
require_once __DIR__ . '/../lib/folders.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    pn_json_error(405, 'Use POST');
}

$username = pn_require_auth();

$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) {
    pn_json_error(400, 'Expected a JSON body');
}

$folder = pn_sanitize_folder($body['folder'] ?? '');
if ($folder === null) {
    pn_json_error(400, 'Folder name must be 1-100 letters, numbers, spaces, "-" or "_"');
}

$userDir = PN_STORAGE_DIR . '/' . preg_replace('/[^A-Za-z0-9_-]/', '_', $username);
$targetDir = $userDir . '/' . $folder;

if (!is_dir($targetDir) && !mkdir($targetDir, 0750, true) && !is_dir($targetDir)) {
    pn_json_error(500, 'Could not create the folder on the server');
}

$resolvedStorageRoot = realpath(PN_STORAGE_DIR);
$resolvedTargetDir = realpath($targetDir);
if ($resolvedStorageRoot === false || $resolvedTargetDir === false ||
    strpos($resolvedTargetDir, $resolvedStorageRoot) !== 0) {
    pn_json_error(500, 'Storage path resolution failed');
}

echo json_encode(['success' => true, 'folder' => $folder]);
