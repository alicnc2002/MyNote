<?php
/**
 * GET /files/load.php?filename=...&folder=saved|temp
 * header: Authorization: Bearer <token>
 * 200 -> {"filename": "...", "folder": "...", "content": "..."}
 */

require_once __DIR__ . '/../lib/token.php';
require_once __DIR__ . '/../lib/folders.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    pn_json_error(405, 'Use GET');
}

$username = pn_require_auth();

$filename = (string)($_GET['filename'] ?? '');
$folder = pn_sanitize_folder($_GET['folder'] ?? 'saved');

if ($folder === null) {
    pn_json_error(400, 'Invalid folder name');
}

// Same filename sanitation as files/save.php -- never trust a
// client-supplied filename against the filesystem without stripping it
// down first.
$safeName = basename($filename);
if ($safeName === '' || $safeName === '.' || $safeName === '..') {
    pn_json_error(400, 'Invalid filename');
}
if (!preg_match('/^[A-Za-z0-9 ._-]{1,255}$/', $safeName)) {
    pn_json_error(400, 'Filename contains unsupported characters');
}

$userDir = PN_STORAGE_DIR . '/' . preg_replace('/[^A-Za-z0-9_-]/', '_', $username);
$targetDir = $userDir . '/' . $folder;
$targetPath = $targetDir . '/' . $safeName;

$resolvedStorageRoot = realpath(PN_STORAGE_DIR);
$resolvedTargetPath = realpath($targetPath);
if ($resolvedStorageRoot === false || $resolvedTargetPath === false ||
    strpos($resolvedTargetPath, $resolvedStorageRoot) !== 0) {
    pn_json_error(404, 'File not found');
}

if (!is_file($targetPath)) {
    pn_json_error(404, 'File not found');
}

$content = file_get_contents($targetPath);
if ($content === false) {
    pn_json_error(500, 'Could not read the file on the server');
}

echo json_encode([
    'filename' => $safeName,
    'folder' => $folder,
    'content' => $content,
]);
