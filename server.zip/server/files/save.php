<?php
/**
 * POST /files/save.php
 * header: Authorization: Bearer <token>
 * body: {"filename": "...", "content": "...", "folder": "saved" | "temp"}
 * 200 -> {"id": "...", "filename": "..."}
 */

require_once __DIR__ . '/../lib/token.php';
require_once __DIR__ . '/../lib/folders.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    pn_json_error(405, 'Use POST');
}

$username = pn_require_auth();

$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) {
    pn_json_error(400, 'Expected a JSON body');
}

$filename = (string)($body['filename'] ?? '');
$content = (string)($body['content'] ?? '');
$folder = pn_sanitize_folder($body['folder'] ?? 'saved');

if ($filename === '') {
    pn_json_error(400, 'filename is required');
}
if ($folder === null) {
    pn_json_error(400, 'Invalid folder name');
}

// Strip any directory component and disallow anything that isn't a plain
// file name -- this is the one thing standing between a malicious filename
// (e.g. "../../../../etc/passwd") and writing outside the storage folder,
// so it isn't optional.
$safeName = basename($filename);
if ($safeName === '' || $safeName === '.' || $safeName === '..') {
    pn_json_error(400, 'Invalid filename');
}
// Keep it to a conservative, unambiguous character set.
if (!preg_match('/^[A-Za-z0-9 ._-]{1,255}$/', $safeName)) {
    pn_json_error(400, 'Filename contains unsupported characters');
}

// Per-user subfolder, so multiple accounts on the same host (if you ever
// add more than one to PN_USERS) can't see or overwrite each other's files.
$userDir = PN_STORAGE_DIR . '/' . preg_replace('/[^A-Za-z0-9_-]/', '_', $username);
$targetDir = $userDir . '/' . $folder;

if (!is_dir($targetDir) && !mkdir($targetDir, 0750, true) && !is_dir($targetDir)) {
    pn_json_error(500, 'Could not create storage folder on the server');
}

$targetPath = $targetDir . '/' . $safeName;

// Belt-and-suspenders: confirm the resolved real path is still inside
// PN_STORAGE_DIR before writing, in case of any symlink/edge-case trickery.
$resolvedStorageRoot = realpath(PN_STORAGE_DIR);
$resolvedTargetDir = realpath($targetDir);
if ($resolvedStorageRoot === false || $resolvedTargetDir === false ||
    strpos($resolvedTargetDir, $resolvedStorageRoot) !== 0) {
    pn_json_error(500, 'Storage path resolution failed');
}

if (file_put_contents($targetPath, $content) === false) {
    pn_json_error(500, 'Could not write the file on the server');
}

echo json_encode([
    'id' => $folder . '/' . $safeName,
    'filename' => $safeName,
]);
