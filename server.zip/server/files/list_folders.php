<?php
/**
 * GET /files/list_folders.php
 * header: Authorization: Bearer <token>
 * 200 -> {"folders": ["saved", "temp", ...]}
 *
 * "saved" and "temp" are always included even if neither has been created
 * on disk yet (a brand-new account has no folders at all until the first
 * save), since the rest of the app treats them as always-valid defaults.
 */

require_once __DIR__ . '/../lib/token.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    pn_json_error(405, 'Use GET');
}

$username = pn_require_auth();

$userDir = PN_STORAGE_DIR . '/' . preg_replace('/[^A-Za-z0-9_-]/', '_', $username);

$folders = ['saved', 'temp'];
if (is_dir($userDir)) {
    foreach (scandir($userDir) as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        if (!is_dir($userDir . '/' . $entry)) {
            continue;
        }
        if (!in_array($entry, $folders, true)) {
            $folders[] = $entry;
        }
    }
}

sort($folders, SORT_STRING | SORT_FLAG_CASE);

echo json_encode(['folders' => $folders]);
