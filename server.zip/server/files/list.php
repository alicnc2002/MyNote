<?php
/**
 * GET /files/list.php?folder=saved|temp
 * header: Authorization: Bearer <token>
 * 200 -> {"files": [{"filename": "...", "size": 123, "modified": "Y-m-d H:i:s"}, ...]}
 */

require_once __DIR__ . '/../lib/token.php';
require_once __DIR__ . '/../lib/folders.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    pn_json_error(405, 'Use GET');
}

$username = pn_require_auth();

$folder = pn_sanitize_folder($_GET['folder'] ?? 'saved');
if ($folder === null) {
    pn_json_error(400, 'Invalid folder name');
}

$userDir = PN_STORAGE_DIR . '/' . preg_replace('/[^A-Za-z0-9_-]/', '_', $username);
$targetDir = $userDir . '/' . $folder;

$files = [];
if (is_dir($targetDir)) {
    foreach (scandir($targetDir) as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        $fullPath = $targetDir . '/' . $entry;
        if (!is_file($fullPath)) {
            continue;
        }
        $files[] = [
            'filename' => $entry,
            'size' => filesize($fullPath),
            'modified' => date('Y-m-d H:i:s', filemtime($fullPath)),
        ];
    }
}

// Newest first -- the file you just saved is the one you're most likely to
// want back.
usort($files, function ($a, $b) {
    return strcmp($b['modified'], $a['modified']);
});

echo json_encode(['files' => $files]);
