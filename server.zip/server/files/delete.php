<?php
/**
 * POST /files/delete.php
 * header: Authorization: Bearer <token>
 * body: {"filename": "...", "folder": "saved" | "temp" | <custom>}
 * 200 -> {"success": true}
 */

require_once __DIR__ . '/../lib/token.php';
require_once __DIR__ . '/../lib/folders.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    pn_json_error(405, 'Use POST');
}

$username = pn_require_auth();

$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) {
    pn_json_error(400, 'Expected a JSON body');
}

$filename = (string)($body['filename'] ?? '');
$folder = pn_sanitize_folder($body['folder'] ?? 'saved');
if ($folder === null) {
    pn_json_error(400, 'Invalid folder name');
}

// Same filename sanitation as files/save.php / files/load.php.
$safeName = basename($filename);
if ($safeName === '' || $safeName === '.' || $safeName === '..') {
    pn_json_error(400, 'Invalid filename');
}
if (!preg_match('/^[A-Za-z0-9 ._-]{1,255}$/', $safeName)) {
    pn_json_error(400, 'Filename contains unsupported characters');
}

$userDir = PN_STORAGE_DIR . '/' . preg_replace('/[^A-Za-z0-9_-]/', '_', $username);
$targetDir = $userDir . '/' . $folder;
$targetPath = $targetDir . '/' . $safeName;

// Belt-and-suspenders path-traversal check, same as load.php, before any
// filesystem mutation.
$resolvedStorageRoot = realpath(PN_STORAGE_DIR);
$resolvedTargetPath = realpath($targetPath);
if ($resolvedStorageRoot === false || $resolvedTargetPath === false ||
    strpos($resolvedTargetPath, $resolvedStorageRoot) !== 0) {
    pn_json_error(404, 'File not found');
}

if (!is_file($targetPath)) {
    pn_json_error(404, 'File not found');
}

if (!unlink($targetPath)) {
    pn_json_error(500, 'Could not delete the file on the server');
}

echo json_encode(['success' => true]);
