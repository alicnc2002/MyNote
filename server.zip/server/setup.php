<?php
/**
 * One-time setup wizard: creates config.local.php (secret key, storage
 * path, first account) without any manual file editing.
 *
 * Works two ways, both handled by this same endpoint:
 *  - Visit this URL in a browser: fills in a form, gets a success page.
 *  - MyNote's Log in screen has a "Create account" option that POSTs
 *    JSON here directly -- no browser step at all.
 *
 * Self-locking: once config.local.php exists, this endpoint refuses to run
 * again, in either mode, so it can't be used to silently add or overwrite
 * accounts later. To reset, delete config.local.php from the server and
 * visit this page again. To add a *second* user by hand afterward, use
 * hash_password.php and edit config.local.php's PN_USERS array directly.
 *
 * Because creating the very first account can't require being logged in
 * yet, this endpoint has no authentication of its own by default -- the
 * self-lock above is what keeps it safe, as long as you run it promptly
 * after uploading server/ so nobody else who finds the URL gets there
 * first. If you'd rather not rely on speed, set PN_SETUP_KEY in config.php
 * *before* uploading -- see the comment there. When it's set, this whole
 * endpoint (including the form itself) refuses every request that doesn't
 * include the matching key.
 */

require_once __DIR__ . '/config.php';

const PN_MIN_PASSWORD_LENGTH = 8;

$configLocalPath = __DIR__ . '/config.local.php';
$alreadyConfigured = is_file($configLocalPath);

// ---- figure out whether this is a JSON (in-app) request or a browser form ----

$rawInput = file_get_contents('php://input');
$jsonBody = json_decode($rawInput, true);
$isJsonRequest = is_array($jsonBody);
$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';

// ---- optional shared-secret gate (PN_SETUP_KEY) -- see config.php ----

function pn_setup_respond_forbidden(bool $isJsonRequest) {
    http_response_code(403);
    if ($isJsonRequest) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Missing or incorrect setup key.']);
    } else {
        header('Content-Type: text/html; charset=utf-8');
        echo <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Forbidden</title></head>
<body style="font-family: sans-serif; max-width: 520px; margin: 40px auto; line-height: 1.5;">
  <h2>Forbidden</h2>
  <p>This server requires a setup key. Append <code>?key=...</code> to this
  URL using the value set for <code>PN_SETUP_KEY</code> in config.php.</p>
</body>
</html>
HTML;
    }
    exit;
}

$setupKeyRequired = defined('PN_SETUP_KEY') && PN_SETUP_KEY !== '';
if ($isJsonRequest) {
    $providedSetupKey = (string)($jsonBody['setup_key'] ?? '');
} else {
    $providedSetupKey = (string)($_POST['setup_key'] ?? $_GET['key'] ?? '');
}
if ($setupKeyRequired && !hash_equals(PN_SETUP_KEY, $providedSetupKey)) {
    pn_setup_respond_forbidden($isJsonRequest);
}
$setupKeyForForm = $setupKeyRequired ? $providedSetupKey : null;

function pn_setup_default_storage_dir(): string {
    // Same heuristic as config.php's fallback: on a typical cPanel layout
    // (public_html/api/ holds this code), two levels up from server/ lands
    // outside public_html, at the account's home directory.
    return dirname(__DIR__, 2) . '/mynote_storage';
}

function pn_setup_generate_token(string $username, string $secretKey, int $ttlSeconds): string {
    // Mirrors lib/token.php's pn_generate_token(), but takes the secret key
    // as a parameter instead of a constant -- config.local.php was just
    // written by this same request, and PHP can't redefine a constant
    // within one process, so we can't require() it and read PN_SECRET_KEY
    // back out again here.
    $expires = time() + $ttlSeconds;
    $payload = $username . '.' . $expires;
    $signature = hash_hmac('sha256', $payload, $secretKey);
    return base64_encode($payload . '.' . $signature);
}

function pn_setup_respond_error(bool $isJsonRequest, string $message, int $httpStatus = 400) {
    global $setupKeyForForm;
    http_response_code($httpStatus);
    if ($isJsonRequest) {
        header('Content-Type: application/json');
        echo json_encode(['error' => $message]);
    } else {
        header('Content-Type: text/html; charset=utf-8');
        pn_setup_render_form($message, null, $setupKeyForForm);
    }
    exit;
}

function pn_setup_render_form(?string $error = null, ?string $storageDirValue = null, ?string $setupKeyValue = null) {
    $storageDirValue = $storageDirValue ?? pn_setup_default_storage_dir();
    $errorHtml = $error ? '<p style="color:#B00020; font-weight:bold;">' . htmlspecialchars($error) . '</p>' : '';
    // Carries the setup key forward as a hidden field so submitting the
    // form doesn't lose it -- only rendered when PN_SETUP_KEY is in use.
    $setupKeyField = $setupKeyValue !== null
        ? '<input type="hidden" name="setup_key" value="' . htmlspecialchars($setupKeyValue) . '">'
        : '';
    echo <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>MyNote server setup</title></head>
<body style="font-family: sans-serif; max-width: 520px; margin: 40px auto; line-height: 1.5;">
  <h2>Set up your MyNote server</h2>
  <p>This runs once. It creates <code>config.local.php</code> with a random secret key, your storage folder, and your login -- nothing to edit by hand.</p>
  {$errorHtml}
  <form method="post">
    {$setupKeyField}
    <label>Username<br>
      <input type="text" name="username" style="width:100%; padding:8px; font-size:14px;" required autofocus>
    </label>
    <p style="margin-top:14px;">Password<br>
      <input type="password" name="password" style="width:100%; padding:8px; font-size:14px;" required minlength="8">
    </p>
    <p>Confirm password<br>
      <input type="password" name="confirm_password" style="width:100%; padding:8px; font-size:14px;" required minlength="8">
    </p>
    <details style="margin-top:14px;">
      <summary style="cursor:pointer;">Advanced: storage folder (auto-detected, usually fine as-is)</summary>
      <p><input type="text" name="storage_dir" style="width:100%; padding:8px; font-size:13px;" value="{$storageDirValue}"></p>
      <p style="color:#666; font-size:12px;">Must be outside your public_html/webroot so files can never be fetched directly by URL.</p>
    </details>
    <button type="submit" style="margin-top:16px; padding:10px 20px; font-size:14px;">Create account</button>
  </form>
</body>
</html>
HTML;
}

function pn_setup_render_success(bool $isJsonRequest, string $baseUrlHint, string $username, ?string $token) {
    if ($isJsonRequest) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'token' => $token, 'username' => $username]);
        return;
    }
    header('Content-Type: text/html; charset=utf-8');
    echo <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Setup complete</title></head>
<body style="font-family: sans-serif; max-width: 520px; margin: 40px auto; line-height: 1.5;">
  <h2 style="color:#2e7d32;">Setup complete</h2>
  <p>In MyNote, Settings &gt; Log in..., use:</p>
  <ul>
    <li>Server URL: <code>{$baseUrlHint}</code></li>
    <li>Username: <code>{$username}</code></li>
    <li>Password: the one you just chose</li>
  </ul>
  <p style="color:#666;">This page won't run again while <code>config.local.php</code> exists, so it's safe to leave deployed. If you also ran <code>hash_password.php</code> earlier, you can delete it now -- this page replaces it.</p>
</body>
</html>
HTML;
}

// ---- already configured: refuse regardless of request type ----

if ($alreadyConfigured) {
    if ($isJsonRequest || $isPost) {
        pn_setup_respond_error($isJsonRequest, 'Already configured. Delete config.local.php on the server to reset.', 409);
    }
    header('Content-Type: text/html; charset=utf-8');
    echo <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Already configured</title></head>
<body style="font-family: sans-serif; max-width: 520px; margin: 40px auto; line-height: 1.5;">
  <h2>Already configured</h2>
  <p>This server already has an account set up. If you want to start over, delete <code>config.local.php</code> from the server and reload this page.</p>
</body>
</html>
HTML;
    exit;
}

// ---- GET with no body yet: show the form ----

if (!$isPost) {
    header('Content-Type: text/html; charset=utf-8');
    pn_setup_render_form(null, null, $setupKeyForForm);
    exit;
}

// ---- POST (either JSON from the app, or the browser form) ----

if ($isJsonRequest) {
    $username = (string)($jsonBody['username'] ?? '');
    $password = (string)($jsonBody['password'] ?? '');
    $confirmPassword = $password; // the app's own dialog handles confirmation
    $storageDir = trim((string)($jsonBody['storage_dir'] ?? ''));
} else {
    $username = (string)($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');
    $storageDir = trim((string)($_POST['storage_dir'] ?? ''));
}

$username = trim($username);
$storageDir = $storageDir !== '' ? $storageDir : pn_setup_default_storage_dir();

if ($username === '' || !preg_match('/^[A-Za-z0-9_-]{1,64}$/', $username)) {
    pn_setup_respond_error($isJsonRequest, 'Username must be 1-64 characters: letters, numbers, "_" or "-" only.');
}
if (strlen($password) < PN_MIN_PASSWORD_LENGTH) {
    pn_setup_respond_error($isJsonRequest, 'Password must be at least ' . PN_MIN_PASSWORD_LENGTH . ' characters.');
}
if ($password !== $confirmPassword) {
    pn_setup_respond_error($isJsonRequest, 'Passwords do not match.');
}
if ($storageDir === '' || $storageDir[0] !== '/') {
    pn_setup_respond_error($isJsonRequest, 'Storage folder must be an absolute path (starting with "/").');
}

// Create + verify the storage folder *before* writing config.local.php --
// if this fails, nothing has been locked in yet and the wizard can just be
// re-run after fixing permissions.
if (!is_dir($storageDir) && !@mkdir($storageDir, 0750, true) && !is_dir($storageDir)) {
    pn_setup_respond_error($isJsonRequest, "Could not create the storage folder at \"$storageDir\". Check permissions, or set a different path under Advanced.", 500);
}
if (!is_writable($storageDir)) {
    pn_setup_respond_error($isJsonRequest, "Storage folder \"$storageDir\" exists but isn't writable. Check its permissions.", 500);
}

$secretKey = bin2hex(random_bytes(32));
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

$configContents = "<?php\n"
    . "/**\n"
    . " * Generated by setup.php on " . date('Y-m-d H:i:s') . ".\n"
    . " * Safe to hand-edit afterward (e.g. to add more users via hash_password.php).\n"
    . " */\n\n"
    . "define('PN_SECRET_KEY', " . var_export($secretKey, true) . ");\n\n"
    . "define('PN_STORAGE_DIR', " . var_export($storageDir, true) . ");\n\n"
    . "define('PN_TOKEN_TTL', 30 * 24 * 60 * 60); // 30 days\n\n"
    . "define('PN_USERS', [\n"
    . "    " . var_export($username, true) . " => " . var_export($passwordHash, true) . ",\n"
    . "]);\n";

if (file_put_contents($configLocalPath, $configContents, LOCK_EX) === false) {
    pn_setup_respond_error($isJsonRequest, 'Could not write config.local.php on the server. Check folder permissions.', 500);
}
@chmod($configLocalPath, 0640);

// Auto-login: hand back a working token immediately so the app (or the
// browser, informationally) doesn't need a separate login round-trip.
$ttl = 30 * 24 * 60 * 60;
$token = pn_setup_generate_token($username, $secretKey, $ttl);

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$baseUrlHint = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'yourdomain.com') . dirname($_SERVER['REQUEST_URI'] ?? '/api/setup.php');

pn_setup_render_success($isJsonRequest, $baseUrlHint, $username, $token);
