# MyNote server

The PHP backend MyNote's Settings > Log in... talks to. Stateless
(HMAC-signed tokens, no database), flat-file storage, one deploy per user
per host -- each person who uses MyNote points it at their *own* copy of
this on their *own* hosting.

## What it does

- `setup.php` -- one-time account creation. Generates your secret key,
  detects/creates your storage folder, and creates your login -- no manual
  file editing. Refuses to run again once it's been used once (see Deploy
  steps below).
- `login.php` -- checks a username/password against `PN_USERS` in your
  config, returns a signed session token.
- `files/save.php` -- checks that token, then writes file content into a
  folder (`saved`, `temp`, or any folder you've created) under your storage
  directory.
- `files/list.php` -- checks that token, returns the filenames (with size
  and last-modified time) already saved in a given folder. Powers the app's
  File > Open from Server dialog.
- `files/load.php` -- checks that token, returns one saved file's content
  by filename, so it can be reopened in a new tab.
- `files/delete.php` -- checks that token, deletes one file by filename +
  folder. Powers the Delete button in Open from Server.
- `files/create_folder.php` -- checks that token, creates a new folder
  under your storage directory (`mkdir -p`-style: creating one that already
  exists just succeeds). Powers the New Folder button in Open from Server.
- `files/list_folders.php` -- checks that token, returns every folder that
  exists under your storage directory, always including `saved` and `temp`
  even before either has been created. Powers the folder picker in Open
  from Server.

That's the whole API. No database required. Folder names outside the
built-in `saved`/`temp` are validated the same way filenames are (a
character allow-list, no `/`, `\`, or `..`), so path traversal isn't
possible no matter what a client sends.

## Deploy steps

1. **Upload this whole `server/` folder** to your host, e.g. as
   `public_html/api/` (so your base URL becomes `https://yourdomain.com/api`).

2. **Set up your account** -- either way works, do whichever's easier:
   - **From MyNote**: Settings > Log in..., enter your server URL
     (`https://yourdomain.com/api`), pick a username and password, and
     click **Create Account**. That's it -- no browser step at all.
   - **Or in a browser**: visit `https://yourdomain.com/api/setup.php`,
     fill in the form (it shows an auto-detected storage folder path you
     can normally just leave as-is), submit.

   Either path writes `config.local.php` for you (random secret key,
   storage folder, your hashed password) and logs you straight in. Run
   this step promptly after uploading -- `setup.php` has no login of its
   own to protect it (there's nothing to log into yet), so by default it
   relies on being used before anyone else who might find the URL gets to
   it (see **Closing the setup race condition** below if you'd rather not
   rely on speed). Once it's run once, it permanently refuses to run again
   (in either mode) unless you delete `config.local.php` from the server,
   so it's safe to leave deployed afterward.

3. **Test it**: in MyNote, Settings > Log in..., server URL =
   `https://yourdomain.com/api`, and the username/password you just chose.

### Closing the setup race condition (optional, recommended)

By default, whoever visits `setup.php` *first* after you upload gets to
create the one account -- there's no way to protect that endpoint with a
login, since there's nothing to log into yet. If you upload and run setup
within a minute or two of each other, this is a non-issue in practice. If
you'd rather not rely on that, set a one-time shared secret **before**
uploading:

1. Open `config.php`, uncomment the `PN_SETUP_KEY` block near the bottom,
   and replace the placeholder with a random string (the comment there
   shows a one-liner to generate one).
2. Upload `server/` as normal.
3. Now `setup.php` refuses every request -- including just viewing the
   form -- unless it includes that same value: append `?key=...` to the
   URL in a browser, or fill in the **Setup key** field on MyNote's Create
   Account screen.

You can remove the `PN_SETUP_KEY` line (or just ignore it) once
`config.local.php` exists -- setup.php is permanently locked at that
point regardless, so the key no longer does anything.

### Adding a second account by hand (optional)

`setup.php` only creates the first account. To add another user later,
visit `https://yourdomain.com/api/hash_password.php`, type a password into
the form, and paste the printed hash into `config.local.php`'s `PN_USERS`
array as a second entry (`'anotherusername' => '<hash>'`). Delete
`hash_password.php` again afterward.

### If setup.php can't create your storage folder automatically

Its auto-detected path assumes a typical cPanel layout
(`public_html/api/` two levels below your account's home directory). If
that guess is wrong for your host, or the folder can't be created due to
permissions, expand "Advanced" on the setup page (or pass a `storage_dir`
if scripting it) and point it at an absolute path **outside**
`public_html`/your webroot -- e.g. `/home/yourusername/mynote_storage`.
750 permissions are fine since only the web server process needs access.

## Security notes (already handled in the code, listed so you know what's
## covered)

- Passwords are hashed (`password_hash`/`password_verify`), never stored or
  compared in plain text.
- Session tokens are HMAC-signed and time-limited (`PN_TOKEN_TTL`), not
  guessable, and don't need a database to validate or revoke (revoke = a
  token's user removed from config, or `PN_SECRET_KEY` rotated).
- Filenames are stripped to a plain basename and checked against an
  allow-list of characters before ever touching the filesystem, blocking
  path-traversal attempts.
- Storage lives outside the webroot by default, so files can't be fetched
  by guessing a URL -- only through the authenticated endpoints. If your
  storage folder ever ends up inside `public_html` anyway, copy
  `storage-folder.htaccess.template` into it as `.htaccess` to block direct
  access as a fallback.
- `.htaccess` blocks directory listing and direct access to
  `config.local.php`, and forces HTTPS where `mod_rewrite` is available.
- `setup.php` permanently refuses to run a second time once
  `config.local.php` exists, so it can never be used to add, overwrite, or
  hijack an existing account -- not even by registering a matching
  username. Optionally gate the *first* run too with `PN_SETUP_KEY` (see
  above) if you don't want that first-come-first-served window at all.

## If you want to share MyNote with other people

Each person deploys their own copy of this `server/` folder on their own
hosting (or a shared one you manage for them) and points their own
MyNote install at their own base URL + login. Nothing in this backend
assumes a single shared server.
