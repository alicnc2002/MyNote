<?php
/**
 * Copy this file to config.local.php (same folder) and fill in real
 * values. config.local.php is your actual, private configuration --
 * never share it or commit it anywhere; it's loaded automatically by
 * config.php if present.
 */

// Generate with: php -r "echo bin2hex(random_bytes(32));"
define('PN_SECRET_KEY', 'PASTE-A-RANDOM-64-CHAR-HEX-STRING-HERE');

// Must be OUTSIDE your public_html/webroot. Example for a typical cPanel
// account (replace "youruser" with your actual cPanel username):
define('PN_STORAGE_DIR', '/home/youruser/mynote_storage');

define('PN_TOKEN_TTL', 30 * 24 * 60 * 60); // 30 days

// Run hash_password.php once (see its header comment), paste the result
// below, then delete hash_password.php from the server.
define('PN_USERS', [
    'yourusername' => '$2y$10$PASTE_YOUR_GENERATED_HASH_HERE',
]);
