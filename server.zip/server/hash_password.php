<?php
/**
 * One-time helper: generates a password hash to paste into config.local.php.
 *
 * HOW TO USE:
 *   1. Upload this file next to config.php.
 *   2. Visit it in your browser once: https://yourdomain.com/api/hash_password.php
 *      and type your password into the form (this avoids the URL-encoding
 *      pitfalls of passing a password as a query string -- spaces, &, +, #,
 *      %, and non-Latin characters can all get silently mangled in a URL).
 *   3. Copy the printed hash into config.local.php's PN_USERS array.
 *   4. DELETE this file from the server. It should never stay deployed --
 *      it exists only to produce one hash, and leaving it up means anyone
 *      who finds the URL can generate hashes for arbitrary passwords
 *      (harmless on its own, but unnecessary attack surface).
 *
 * CLI usage is still supported and is the safest option if you have SSH
 * access, since it never touches a URL or a browser form:
 *   php hash_password.php yourActualPassword
 */

header('Content-Type: text/plain');

$password = null;

if (php_sapi_name() === 'cli') {
    $password = $argv[1] ?? null;
    if (!$password) {
        echo "Usage (CLI): php hash_password.php yourActualPassword\n";
        exit;
    }
    echo "Password hash (paste into config.local.php):\n\n";
    echo password_hash($password, PASSWORD_DEFAULT) . "\n\n";
    echo "Remember to delete this file from the server once you've copied the hash.\n";
    exit;
}

// Browser: prefer POST (from the form below) over GET, since GET query
// strings are subject to URL-encoding pitfalls that can silently change
// the password before it ever reaches PHP.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? null;
} else {
    // Still accepted for convenience/backwards compatibility, but the form
    // below is the recommended path.
    $password = $_GET['password'] ?? null;
}

if (!$password) {
    header('Content-Type: text/html; charset=utf-8');
    echo <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Generate password hash</title></head>
<body style="font-family: sans-serif; max-width: 480px; margin: 40px auto;">
  <h2>Generate a MyNote password hash</h2>
  <p>Type the password exactly as you'll type it into MyNote's login screen. Using this form (POST) avoids the URL-encoding issues that GET query strings have with spaces and symbols.</p>
  <form method="post">
    <input type="password" name="password" style="width: 100%; padding: 8px; font-size: 14px;" autofocus required>
    <button type="submit" style="margin-top: 10px; padding: 8px 16px;">Generate hash</button>
  </form>
  <p style="color: #900; margin-top: 24px;">Delete this file from the server once you've copied the hash.</p>
</body>
</html>
HTML;
    exit;
}

echo "Password hash (paste into config.local.php):\n\n";
echo password_hash($password, PASSWORD_DEFAULT) . "\n\n";
echo "Remember to delete this file from the server once you've copied the hash.\n";
